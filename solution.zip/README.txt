Team Members: Cooper Berube, Brendan Meixner

Milestone 1:
We worked concurrently on all 4 functions in the Library.

Minestone 2:

Cooper:
- uint256_mul
- uint256_format_as_hex
- uint256_create_from_hex
- Unit Tests

Brendan:
- uint256_add
- uint256_sub
- uint256_negate
- uint256_lshift
- Testing functionality within given tests