TODO: names of team members and their contributions to the project

MSII:

Cooper Berube:
- cacheSimFuncs.h
- main.cpp
- address handling

Brendan Meixner:
- Command Line Arguement functionality
- getTag, getIndex
- evict, evictBlock

TODO (for MS3): best cache report
