TODO: names of team members
1. Cooper Berube
2. Brendan Meixner

TODO: contributions of each team member

Cooper Berube:
- Unit Tests
- Greyscale
- RGB
- Fade

Brendan Meixner:
- Unit Tests
- Kaleidoscope
- Comments for clarity
