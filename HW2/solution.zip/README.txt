TODO: names of team members
1. Cooper Berube
2. Brendan Meixner

TODO: contributions of each team member

MSI:

Cooper Berube:
- Unit Tests
- Greyscale
- RGB
- Fade

Brendan Meixner:
- Unit Tests
- Kaleidoscope
- Comments for clarity

MSII:
Cooper Berube:
- Assembly helper functions

Brendan Meixner:
- Grayscale
- Unit Tests

Both:
- RGB
